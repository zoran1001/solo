// 网站内容数据
const websiteContent = {
    // 全局设置
    global: {
        title: "My Design Universe",
        description: "Breakthrough Conventional Creative Expression",
        primaryColor: "#ff0000",
        backgroundColor: "#000000",
        secondaryColor: "#111111",
        textPrimary: "#ffffff",
        textSecondary: "rgba(255, 255, 255, 0.8)",
        borderColor: "rgba(255, 0, 0, 0.2)"
    },
    
    // 首页Banner
    banner: {
        title: "Welcome to My Design World",
        subtitle: "Discover the Art of Creative Design",
        image: "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
        ctaText: "Explore Works",
        ctaLink: "#showcase"
    },
    
    // 英雄区域
    hero: {
        title1: "Design Without Boundaries",
        title2: "Boundless Creativity",
        subtitle: "A Design Journey Beyond the Norm",
        ctaText: "**A Design Journey Beyond the Norm**",
        edgeTextRight: {
            line1: "Graphic Designer",
            line2: "Visual Communication Design",
            line3: "2021 – PRESENT"
        },
        edgeTextBottom: {
            line1: "Keep the Passion",
            line2: "World Peace",
            line3: "Happiness Every Day"
        }
    },
    
    // 作品展示
    works: {
        title: "My design works",
        subtitle: "Breakthrough Conventional Creative Expression",
        items: [
            {
                id: "work-1",
                type: "large",
                title: "Brand Design",
                category: "Graphic Design",
                gradient: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
                description: [
                    "This is a comprehensive brand design project for a modern startup. The project includes logo design, brand identity, packaging design, and marketing materials.",
                    "The design concept revolves around minimalism and modern aesthetics, using a clean color palette and geometric shapes to create a strong visual identity."
                ],
                details: {
                    client: "Tech Startup Inc.",
                    year: "2024",
                    services: "Logo Design, Brand Identity, Packaging"
                }
            },
            {
                id: "work-3",
                type: "small",
                title: "AI-generated",
                category: "AI Design",
                gradient: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
                image: "https://images.unsplash.com/photo-1677442136607-d81b6006d972?ixlib=rb-1.2.1&auto=format&fit=crop&w=1374&q=80",
                description: [
                    "This collection showcases the potential of AI-generated art. Using advanced machine learning algorithms, we created a series of unique and captivating visual artworks.",
                    "Each piece combines human creativity with AI capabilities, resulting in stunning visuals that push the boundaries of traditional art."
                ],
                details: {
                    client: "Art Gallery Exhibition",
                    year: "2024",
                    services: "AI Art Generation, Digital Artwork"
                }
            },
            {
                id: "work-4",
                type: "small",
                title: "Website Design",
                category: "Web Design",
                gradient: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
                image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
                description: [
                    "A modern, responsive website design for a creative agency. The design focuses on user experience and visual appeal, with a clean layout and smooth animations.",
                    "The website is fully responsive, ensuring optimal viewing experience across all devices and screen sizes."
                ],
                details: {
                    client: "Creative Agency",
                    year: "2024",
                    services: "Web Design, UI/UX Design, Responsive Development"
                }
            },
            {
                id: "work-5",
                type: "medium",
                title: "Illustration Design",
                category: "Creative Design",
                gradient: "linear-gradient(135deg, #fa709a 0%, #fee140 100%)",
                image: "https://images.unsplash.com/photo-1513694203232-719a280e022f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
                description: [
                    "A collection of creative illustrations for various projects. The illustrations feature a unique style with bold colors and dynamic compositions.",
                    "The project includes editorial illustrations, children's book illustrations, and concept art for video games."
                ],
                details: {
                    client: "Multiple Clients",
                    year: "2024",
                    services: "Illustration, Concept Art, Digital Painting"
                }
            },
            {
                id: "work-6",
                type: "large",
                title: "3D Design",
                category: "3D Design",
                gradient: "linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)",
                image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
                description: [
                    "A showcase of 3D design projects, including product visualization, architectural rendering, and character design.",
                    "Using industry-standard 3D software, we created realistic and visually stunning 3D models and renderings."
                ],
                details: {
                    client: "Design Studio",
                    year: "2024",
                    services: "3D Modeling, Rendering, Product Visualization"
                }
            }
        ]
    },
    
    // 关于我
    about: {
        title: "About Me",
        content: [
            "I am a passionate designer who specializes in creating unique and impactful design works. I believe that design is not just about visual appeal but also about solving problems and conveying emotions. ",
            "My design philosophy is to combine innovation with simplicity, breaking the norms and creating memorable design experiences. I constantly explore new design techniques and trends to keep my works fresh and forward-looking.",
            "I excel at translating complex concepts into clear and powerful visual language, using design to tell stories and evoke emotions."
        ],
        image: "https://images.unsplash.com/photo-1552058544-f2b08422138a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80"
    },
    
    // 专业技能
    skills: {
        title: "Professional Skills",
        subtitle: "My Design Toolkit",
        items: [
            {
                title: "Graphic Design",
                icon: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>'
            },
            {
                title: "UI/UX Design",
                icon: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>'
            },
            {
                title: "Web Design",
                icon: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>'
            },
            {
                title: "Illustration Design",
                icon: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>'
            },
            {
                title: "3D Design",
                icon: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>'
            },
            {
                title: "Packaging Design",
                icon: '<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>'
            }
        ]
    },
    
    // 联系方式
    contact: {
        title: "Contact Me",
        subtitle: "Let's Start Our Design Collaboration",
        email: "design@example.com",
        phone: "+86 123 4567 8910",
        socialLinks: [
            { name: "Instagram", url: "#" },
            { name: "Behance", url: "#" },
            { name: "Dribbble", url: "#" }
        ]
    }
};

// 导出数据（如果在模块化环境中使用）
if (typeof module !== 'undefined' && module.exports) {
    module.exports = websiteContent;
}